# CensorDodge
Censor Dodge is a fast growing company that aims to provide the fastest and most up-to-date web proxy on the market.
The completely open-source web proxy script was refined over many years, with the core focus on making it lightweight and fully customisable. Also for those of us who are novices, we provide the pioneering one-click proxy setup service free of charge.

# Features
* The main features of Censor Dodge:
    1. Fast and lightweight. Lightning fast straight out of the box.
	2. Personalised and attachable themes. Customization support and extensive designing options.
	3. Integrated plugin support. Add additional features throughout the code easily.
	4. Fully cross-browser compatible. Works with all browsers (even Internet Explorer).

# NOTE
This repository is a mirror of the code released on `censordodge.com`. The author of Censor Dodge is Ryan Maber.
